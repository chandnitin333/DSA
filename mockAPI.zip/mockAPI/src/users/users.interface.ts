import { User } from "./user.interface";

export interface Users {
    [id: string]: User;
}